!!! JERZ KITS !!!
A hilarious tribute to
a very notorious LSDJ kit

Contains various samples used
in many Jersey club tracks.

THESE REQUIRE PATCHING INTO
LSDJ 9.4.0 or HIGHER
NO GUARANTEES ON ANY VERSION LOWER

Enjoy the free samples. :3

Sincerely,
Chelsea E.
<3
